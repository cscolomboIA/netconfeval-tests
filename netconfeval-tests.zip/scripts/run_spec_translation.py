print('run_spec_translation placeholder')
